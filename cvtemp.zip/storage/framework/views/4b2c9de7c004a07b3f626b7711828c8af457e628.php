<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <title>CVTemp</title>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Favicons for Desktop, iOS and android -->
    <link rel="icon" type="image/png" sizes="32x32" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/favicon-16x16.png">
    <link rel="apple-touch-icon" sizes="180x180" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="192x192" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/android-chrome-192x192.png">
    <link rel="mask-icon" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/safari-pinned-tab.svg" color="#5bbad5">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,900" rel="stylesheet">

    <link href="<?php echo e(URL('home_assest/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/simple-line-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/magnific-popup.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/owl.theme.default.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/aos.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/color-switcher.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/color-1.css')); ?>" rel="stylesheet">

    <!--[if IE]>
    <link href="../assets/css/ie.css" rel="stylesheet">
    <![endif]-->

    <script src="<?php echo e(URL('home_assest/modernizr.js')); ?>"></script>

    <!--[if lt IE 9]>
    <script src="../assets/js/html5shiv.js"></script>
    <script src="../assets/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

<div id="page" class="site"> <div class="baseline-grid1"></div>

    <!-- Start Header -->
    <header id="masthead" class="site-header">

        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </header>
    <!-- End Header -->

    <div id="content" class="site-content">
        <div id="primary" class="content-area">
            <main id="main" class="site-main">

                <!-- Start Contact us -->
                <section id="contact-us---1" class="container-fluid section-block contact-form-section">
                    <div class="form-bg"></div> <!-- Background image -->
                    <div class="overlay"></div>	<!-- Overlay -->
                    <div class="container">
                        <div class="row">

                            <!-- Start Contact Form -->
                            <div class="col-md-10 center-form border-box" style="margin-top: 20px;padding-bottom: 100px;">
                                <form id="form_two" class="contact-form" method="post" action="<?php echo e(URL('/form2/submit')); ?>" >
                                    <?php echo csrf_field(); ?>

                                    <div class="col-md-12">
                                        <input id="address1" class="address1" type="text" name="address" placeholder="Address line " required>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="contact-f-name" class="contact-f-name" type="text" name="fullname" placeholder="Full Name" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="contact-Date of birth" class="contact-Date of birth" type="text" name="dob" placeholder="Date of birth" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="contact_no" class="contact_no" type="text" name="contact_no" placeholder="Contact No" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="contact-Sex" class="contact-Sex" type="text" name="sex" placeholder="Sex" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="contact-Age" class="contact-Age" type="text" name="age" placeholder="Age" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="contact-NIC number" class="contact-NIC number" type="text" name="nic" placeholder="NIC number" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="contact-Driving License" class="contact-Driving License" type="text" name="driving_license" placeholder="Driving License" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="contact-Civil Status" class="contact-Civil Status" type="text" name="civil_status" placeholder="Civil Status" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="contact-Religion" class="contact-Religion" type="text" name="religion" placeholder="Religion" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="contact-Nationality" class="contact-Nationality" type="text" name="nationality" placeholder="Nationality" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="contact-School" class="contact-School" type="text" name="school" placeholder="School" required>
                                    </div>


                                    <div class="col-md-12">

                                        <h3>Education Qulifications</h3>
                                        <h4>G.C.E.(O/L) Examination</h4>

                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject1" placeholder="Subject1" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results1" placeholder="Results1" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject2" placeholder="Subject2">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results2" placeholder="Results2" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject3" placeholder="Subject3" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results3" placeholder="Results3" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject4" placeholder="Subject4" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results4" placeholder="Results4" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject5" placeholder="Subject5" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results5" placeholder="Results5" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject6" placeholder="Subject6" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results6" placeholder="Results6" >
                                    </div>


                                    <div class="col-md-12"><h5>Work Expirence</h5></div>


                                    <div class="col-md-6">
                                        <input id="Company" class="Company" type="text" name="company" placeholder="Company" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Period" class="Period" type="text" name="period" placeholder="Period" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Worked Years" class="Worked Years" type="text" name="worked_years" placeholder="Worked Years" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Covered area" class="Covered area" type="text" name="covered_area" placeholder="Covered area" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="City worked in" class="City worked in" type="text" name="city_work" placeholder="City worked in" required>
                                    </div>


                                    <div class="col-md-12">
                                        <h4>Language Fluency</h4>
                                    </div>


                                    <div class="col-md-12">
                                        <input id="contact-Enter Languages" class="contact-Enter Languages" type="text" name="language" placeholder="Enter Languages" required>
                                    </div>




                                    <div class="col-md-12">

                                        <h4>NON-RELATED REFEREES</h4>

                                    </div>


                                    <div class="col-md-6">
                                        <input id="non_refree1_name" class="non_refree1_name" type="text" name="non_refree1_name" placeholder="Non Related Referee1 Name" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="non_refree1_post" class="non_refree1_post" type="text" name="non_refree1_post" placeholder="Non Related Referee1 Post" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="non_refree1_workplace" class="non_refree1_workplace" type="text" name="non_refree1_workplace" placeholder="Non Related Referee1 working Place" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="non_refree1_tel" class="non_refree1_tel" type="text" name="non_refree1_tel" placeholder="Contact Number of Referee1" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="non_refree2_name" class="non_refree2_name" type="text" name="non_refree2_name" placeholder="Non Related Referee2 Name" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="non_refree2_post" class="non_refree2_post" type="text" name="non_refree2_post" placeholder="Non Related Referee2 Post" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="non_refree2_workplace" class="non_refree2_workplace" type="text" name="non_refree2_workplace" placeholder="Non Related Referee2 working Place" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="non_refree2_tel" class="non_refree2_tel" type="text" name="non_refree2_tel" placeholder="Contact Number of Referee2" >
                                    </div>


                                    <div class="clearfix"></div>

                                    <div class="col-md-12 form-btn-submit">
                                        <input id="contact-button" class="button button-full contact-submit" value="Submit" type="submit">
                                    </div>

                                </form>
                            </div>
                            <!-- End Contact Form -->

                        </div> <!-- .row -->
                    </div> <!-- .container -->
                </section>
                <!-- End Contact us -->

                <!-- Start Newsletter -->
            
            
            

            
            
            
            

            
            
            
            
            
            
            
            
            
            

            
            
            
            <!-- End Newsletter -->

            </main>
        </div> <!-- #primary -->
    </div> <!-- #content -->

    <!-- Start Footer -->






























































<!-- End Footer -->

</div> <!-- #page -->

<!-- Include JS -->
<script src="<?php echo e(URL('home_assest/jquery.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/bootstrap-hover-dropdown.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/parallax.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/aos.js')); ?>"></script>

<script src="<?php echo e(URL('init.js')); ?>"></script>




<![endif]-->

<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','../../../../www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-80974374-1', 'auto');
    ga('send', 'pageview');

</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\cvtemp\resources\views/form2.blade.php ENDPATH**/ ?>