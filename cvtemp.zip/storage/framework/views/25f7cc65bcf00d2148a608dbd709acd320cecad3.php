<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e($user_email); ?></title>

</head>
<body>
<div  style="500px;text-align: center;">


    <h3>CURRICULUM VITAE</h3>

</div>



<label><?php echo e($data->full_name); ?>,</label> <br>
<label><?php echo e($data->address); ?></label> <br>
<label><?php echo e($data->contact_no); ?>,</label> <br>

<div><h4 style="background: lightskyblue">
        PERSONAL DETAILS
    </h4></div>



<label>Name in Full  :  <?php echo e($data->full_name); ?> </label> <br>

<label>Date of Birth  :  <?php echo e($data->dob); ?></label> <br>

<label>Sex      :    <?php echo e($data->sex); ?>  </label> <br>

<label>Age      :      <?php echo e($data->age); ?></label> <br>

<label>NIC No      :      <?php echo e($data->nic); ?></label> <br>

<label>Driving Liense      :      <?php echo e($data->driving_license); ?></label> <br>

<label>Civil Status      :      <?php echo e($data->civil_status); ?> </label> <br>

<label>Religion      :     <?php echo e($data->religion); ?></label> <br>

<label>Nationality     :     <?php echo e($data->nationality); ?></label> <br>

<label>School      :      <?php echo e($data->school); ?></label> <br>

<div><h4 style="background: lightskyblue">
        EDUCATION QULIFICATION
    </h4></div>

<div><h4>
        G.C.E (O/L) Examiniation 2012
    </h4></div>

<table>
    <tr style="text-align:left;">
        <th style="width: 177px;">Subject</th><br>

        <th>Grade</th>
    </tr>
    <tr>
        <td><?php echo e($data->subject1); ?></td>

        <td><?php echo e($data->result1); ?></td>
    </tr>
    <tr>
        <td><?php echo e($data->subject2); ?></td>

        <td><?php echo e($data->result2); ?></td>
    </tr>
    <tr>
        <td><?php echo e($data->subject3); ?></td>
        <td><?php echo e($data->result3); ?></td>
    </tr>

    <tr>
        <td><?php echo e($data->subject4); ?></td>
        <td><?php echo e($data->result4); ?></td>
    </tr>

    <tr>
        <td><?php echo e($data->subject5); ?></td>
        <td><?php echo e($data->result5); ?></td>
    </tr>

    <tr>
        <td><?php echo e($data->subject6); ?></td>
        <td><?php echo e($data->result6); ?></td>
    </tr>


</table>


<div><h4 style="background: lightskyblue">
        WORKING EXPIRENCE
    </h4></div>

<label>Company  :  <?php echo e($data->company); ?></label> <br><br>

<label>Period     :    <?php echo e($data->period); ?>  </label> <br><br>

<label>Worked Years      :      <?php echo e($data->work_years); ?></label> <br><br>

<label>Covered area      :    <?php echo e($data->cover_area); ?></label> <br><br>

<label>Worked City      :    <?php echo e($data->work_city); ?></label> <br><br>

<div><h4 style="background: lightskyblue">
        LANGUAGE FLAUANCY
    </h4></div>

<label><?php echo e($data->language); ?></label> <br><br>

<div class="page_break" style="page-break-before: always;"></div>

<div>
    <h4 style="background: lightskyblue">Non Related Referees</h4>

    <table style="height: 110px" width="670px"border="0">
        <tr>
            <td>
                <?php echo e($data->non_refree1_name); ?>.,<br>
                <?php echo e($data->non_refree1_post); ?><br>
                <?php echo e($data->non_refree1_workplace); ?><br>
                <?php echo e($data->non_refree1_tel); ?><br>

            </td>
            <td>
                <?php echo e($data->non_refree2_name); ?>.,<br>
                <?php echo e($data->non_refree2_post); ?><br>
                <?php echo e($data->non_refree2_workplace); ?><br>
                <?php echo e($data->non_refree2_tel); ?><br>
            </td>
        </tr>
    </table>

    <p>I wish to conform that above particulars are true and correct to the best of my knowledge.
        If any of the particulars are found to be incurred before of after selection of employment I
        am aware that I would be disqualified of the label termination of service without
        compensation.</p>

    <table style="height: 110px" width="670px"border="0">
        <tr>
            <td>
                ................................
            </td>
            <td>
                ................................
            </td>
        </tr>
        <tr>
            <td>
                Date
            </td>
            <td>
                Signature of Applicant
            </td>
        </tr>
    </table>

</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\cvtemp\resources\views/pdf/form2_pdf.blade.php ENDPATH**/ ?>