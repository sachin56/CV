<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e($user_email); ?></title>

</head>
<body>
<table style="height: 40px" width="670px" bgcolor="#4D81D2" align="center" bordercolor="#8F9BF9" border="0">
    <tr><td style="text-align: center"><b>CURRICULUM VITAE</b></td></tr>
</table>
<br>
<br>

<table style="height: 120px" width="670px" align="center"  border="1">

    <td style="text-align: center">
        <br>
        <?php echo e($data->full_name); ?><br>
        <?php echo e($data->address); ?>,<br>
        <?php echo e($data->email); ?><br>
        <?php echo e($data->contact_no1); ?>, <?php echo e($data->contact_no2); ?>

    </td>

</table>
<br>
<br>

<table style="height: 20px" width="670px" bgcolor="#4D81D2" align="center" border="0">
    <tr><td><b>Profile</b></td></tr>
</table>

<br>
<br>
<table style="height: 110px" width="670px" align="center"  border="1">
    <tr>
        <td>
            <ul type="disc">
                <li><?php echo e($data->statement1); ?></li>
                <li><?php echo e($data->statement2); ?>

                </li>
                <li><?php echo e($data->statement3); ?>

                </li>
                <li><?php echo e($data->statement4); ?></li>
                <li><?php echo e($data->statement5); ?>

                </li>
            </ul>
        </td>
    </tr>

</table>
<br>
<br>

<table style="height: 20px" width="670px" bgcolor="#4D81D2" align="center" border="0">
    <tr><td><b>Professional Qualifications</b></td></tr>
</table>

<br>
<br>
<table style="height: 110px" width="670px" align="center" border="1">
    <tr>
        <td>
            <ul type="disc">
                <li><?php echo e($data->skill1); ?>

                </li>
                <li><?php echo e($data->skill2); ?>

                </li>
                <li><?php echo e($data->skill3); ?>

                </li>
                <li><?php echo e($data->skill4); ?>

                </li>
                <li><?php echo e($data->skill5); ?>

                </li>
            </ul>
        </td>
    </tr>
</table>
<br>
<br>
<div class="page_break" style="page-break-before: always;"></div>
<table style="height: 20px" width="670px" bgcolor="#4D81D2" align="center" border="0">
    <tr><td><b>Educational Qualifications</b></td></tr>
</table>
<br>
<br>

<table style="height: 110px" width="670px" align="center" border="0">
    <tr>
        <td>
            <ul type="disc">
                <li> 	G.C.E  Advanced Level (<?php echo e($data->al_stream); ?> stream) – <?php echo e($data->al_year); ?>	(Index No: <?php echo e($data->al_index); ?>)
                </li>
                <br>
                <br>
                <table width="200px" border="0">
                    <tr>
                        <td><b>Subject</b></td>
                        <td><b>Grade</b></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->al_subject1); ?></td>
                        <td><?php echo e($data->al_result1); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->al_subject2); ?></td>
                        <td><?php echo e($data->al_result2); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->al_subject3); ?></td>
                        <td><?php echo e($data->al_result3); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->al_subject4); ?></td>
                        <td><?php echo e($data->al_result4); ?></td>
                    </tr>
                </table>
                <br>
                <br>
                <li> 	G.C.E  Ordinary Level – <?php echo e($data->ol_year); ?>	(Index No: <?php echo e($data->ol_index); ?>)
                </li>
                <br>
                <br>
                <table width="200px" border="0">
                    <tr>
                        <td><b>Subject</b></td>
                        <td><b>Grade</b></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->subject1); ?></td>
                        <td><?php echo e($data->result1); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->subject2); ?></td>
                        <td><?php echo e($data->result2); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->subject3); ?></td>
                        <td><?php echo e($data->result3); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->subject4); ?></td>
                        <td><?php echo e($data->result4); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->subject5); ?></td>
                        <td><?php echo e($data->result5); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->subject6); ?></td>
                        <td><?php echo e($data->result6); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->subject7); ?></td>
                        <td><?php echo e($data->result7); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->subject8); ?></td>
                        <td><?php echo e($data->result8); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->subject9); ?></td>
                        <td><?php echo e($data->result9); ?></td>
                    </tr>
                </table>
            </ul>
        </td>
    </tr>
</table>
<br>
<br>

<table style="height: 20px" width="670px" bgcolor="#4D81D2" align="center" border="0">
    <tr><td><b>Project Completed</b></td></tr>
</table>
<br>
<br>
<table style="height: 110px" width="670px" align="center"  border="1">
    <tr>
        <td>
            <ul type="disc">
                <li> 	<?php echo e($data->project1); ?></li>
                <li> 	<?php echo e($data->project2); ?>

                </li>

            </ul>
        </td>
    </tr>

</table>
<br>
<br>
<div class="page_break" style="page-break-before: always;"></div>
<table style="height: 20px" width="670px" bgcolor="#4D81D2" align="center" border="0">
    <tr><td><b>Experience</b></td></tr>
</table>

<br>
<br>
<table style="height: 110px" width="670px" align="center" border="1">
    <tr>
        <td>
            <ul type="disc">
                <li> <?php echo e($data->experience1); ?>


                </li>

            </ul>
        </td>
    </tr>
</table>
<br>
<br>

<table style="height: 20px" width="670px" bgcolor="#4D81D2" align="center" border="0">
    <tr><td><b>Personal Details</b></td></tr>
</table>

<br>
<br>
<table style="height: 110px" width="670px" align="center" border="1">
    <tr>
        <td>
            <ul type="disc">
                <li> 	Full Name		: <?php echo e($data->name_full); ?>

                </li>
                <li> 	Date of birth 		: <?php echo e($data->dob); ?>

                </li>
                <li> 	Nationality 		: <?php echo e($data->nationality); ?>

                </li>
                <li> 	Gender 		: <?php echo e($data->gender); ?>

                </li>
                <li> 	N.I.C No 		: <?php echo e($data->nic); ?>

                </li>
                <li> 	Civil Status 		: <?php echo e($data->civil_status); ?>

                </li>
                <li> 	School attended	: <?php echo e($data->school); ?>

                </li>
            </ul>
        </td>
    </tr>
</table>
<br>
<br>

<table style="height: 20px" width="670px" bgcolor="#4D81D2" align="center" border="0">
    <tr><td><b>Non-Related Referees</b></td></tr>
</table>

<br>
<br>
<table style="height: 110px" width="670px" align="center" border="0">
    <tr>
        <td>
            <?php echo e($data->non_refree1_name); ?>,<br>
            <?php echo e($data->non_refree1_post); ?><br>
            <?php echo e($data->non_refree1_workplace); ?><br>
            <?php echo e($data->non_refree1_address); ?><br>
            Tel : <?php echo e($data->non_refree1_tel); ?><br>
            Email: <?php echo e($data->non_refree1_email); ?>

        </td>
        <td>
            <?php echo e($data->non_refree2_name); ?>,<br>
            <?php echo e($data->non_refree2_post); ?><br>
            <?php echo e($data->non_refree2_workplace); ?><br>
            <?php echo e($data->non_refree2_address); ?><br>
             <?php echo e($data->non_refree2_tel); ?><br>
            <?php echo e($data->non_refree2_email); ?>

        </td>
    </tr>
</table>
<br>
<br>
<br>
<table style="height: 110px" width="670px" align="center" border="0">
    <tr><td>
            I hereby certify that the above information is correct and complete to the best of my knowledge & belief.
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
        </td>
    </tr>
    <tr>

        <td>
            ………………………<br>
            <?php echo e($data->full_name); ?>

        </td>
        <td>
            ……………………………<br>
            Date
        </td>

    </tr>
</table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cvtemp\resources\views/pdf/form3_pdf.blade.php ENDPATH**/ ?>