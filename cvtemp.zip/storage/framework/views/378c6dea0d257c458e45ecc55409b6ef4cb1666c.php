<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.harbourthemes.com/demo/dot/blocks/forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 02 Jul 2020 17:42:56 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <title>CVTemp</title>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Favicons for Desktop, iOS and android -->
    <link rel="icon" type="image/png" sizes="32x32" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/favicon-16x16.png">
    <link rel="apple-touch-icon" sizes="180x180" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="192x192" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/android-chrome-192x192.png">
    <link rel="mask-icon" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/safari-pinned-tab.svg" color="#5bbad5">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,900" rel="stylesheet">

    <link href="<?php echo e(URL('home_assest/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/simple-line-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/magnific-popup.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/owl.theme.default.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/aos.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/color-switcher.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/color-1.css')); ?>" rel="stylesheet">

    <!--[if IE]>
    <link href="../assets/css/ie.css" rel="stylesheet">
    <![endif]-->

    <script src="<?php echo e(URL('home_assest/modernizr.js')); ?>"></script>

    <!--[if lt IE 9]>
    <script src="../assets/js/html5shiv.js"></script>
    <script src="../assets/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

<div id="page" class="site"> <div class="baseline-grid1"></div>

    <!-- Start Header -->
    <header id="masthead" class="site-header">

        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </header>
    <!-- End Header -->

    <div id="content" class="site-content">
        <div id="primary" class="content-area">
            <main id="main" class="site-main">

                <!-- Start Contact us -->
                <section id="contact-us---1" class="container-fluid section-block contact-form-section">
                    <div class="form-bg"></div> <!-- Background image -->
                    <div class="overlay"></div>	<!-- Overlay -->
                    <div class="container">
                        <div class="row">

                            <!-- Start Contact Form -->
                            <div class="col-md-10 center-form border-box" style="margin-top: 20px;padding-bottom: 100px;">
                                <form id="form_four" class="contact-form" method="post" action="<?php echo e(URL('/form4/submit')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-md-12">
                                        <input id="contact-f-name" class="contact-f-name" type="text" name="fullname" placeholder="Full Name" required>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="address1" class="address1" type="text" name="address" placeholder="Address" required>
                                    </div>
                                    <div class="col-md-6">
                                        <input id="address3" class="address3" type="text" name="contact1" placeholder="Contact No 1" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="address3" class="address3" type="text" name="contact2" placeholder="Contact No 2" required>
                                    </div>


                                    <div class="col-md-6">
                                        <input id="contact-email" class="contact-email" type="email" name="email" placeholder="Email" required>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="contact-Objective" class="contact-Objective" type="text" name="objective" placeholder="Objective" required>
                                    </div>

                                    <div class="col-md-12">
                                        <h3>Education Qulifications</h3>
                                        <h4>G.C.E.(O/L) Examination</h4>

                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject1" placeholder="Subject" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results1" placeholder="Results" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject2" placeholder="Subject">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results2" placeholder="Results">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject3" placeholder="Subject" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results3" placeholder="Results">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject4" placeholder="Subject">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results4" placeholder="Results">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject5" placeholder="Subject">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results5" placeholder="Results">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject6" placeholder="Subject">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results6" placeholder="Results" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject7" placeholder="Subject" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results7" placeholder="Results" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject8" placeholder="Subject" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results8" placeholder="Results">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject9" placeholder="Subject" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results9" placeholder="Results"  >
                                    </div>
                                    <div class="col-md-12"><h4>G.C.E.(A/L) Examination</h4></div>
                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="al_subject1" placeholder="Subject"  required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="al_results1" placeholder="Results"  required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="al_subject2" placeholder="Subject"  >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="al_results2" placeholder="Results"  >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="al_subject3" placeholder="Subject"  >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="al_results3" placeholder="Results" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="al_subject4" placeholder="Subject"  >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="al_results4" placeholder="Results"  >
                                    </div>

                                    <div class="col-md-12">
                                        <h4>Higher Education</h4>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="contact-Enter Details" class="contact-Enter Details" type="text" name="higher_edu" placeholder="Enter Details"  required>
                                    </div>

                                    <div class="col-md-12">
                                        <h4>Other Achievements</h4>
                                    </div>


                                    <div class="col-md-12">
                                        <input id="contact-Achievements One" class="contact-Achievements One" type="text" name="other1" placeholder="Achievements One" required>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="contact-Achievements Two" class="contact-Achievements One" type="text" name="other2" placeholder="Achievements Two" >
                                    </div>


                                    <div class="col-md-12">
                                        <input id="contact-Achievements Three" class="contact-Achievements Three" type="text" name="other3" placeholder="Achievements Three" >
                                    </div>





                                    <div class="col-md-12">
                                        <h3>Work Experience</h3>

                                    </div>


                                    <div class="col-md-12">
                                        <input id="job_title" class="job_title" type="text" name="work_xp1" placeholder="Job Title" required>
                                    </div>


                                    <div class="col-md-12">
                                        <input id="job_description" class="job_description" type="text" name="work_xp1_description" placeholder="Job Description" required>
                                    </div>


                                    <div class="col-md-12">
                                        <h3 style="font-size: x-large;">Responsibities</h3>

                                    </div>

                                    <div class="col-md-12">
                                        <input id="responsibity_one" class="responsibity" type="text" name="work_xp1_res1" placeholder="Responsibity" required>
                                    </div>


                                    <div class="col-md-12">
                                        <input id="responsibity_two" class="responsibity" type="text" name="work_xp1_res2" placeholder="Responsibity" >
                                    </div>


                                    <div class="col-md-12">
                                        <input id="responsibity_three" class="responsibity" type="text" name="work_xp1_res3" placeholder="Responsibity" >
                                    </div>


                                    <div class="col-md-12">
                                        <input id="responsibity_four" class="responsibity" type="text" name="work_xp1_res4" placeholder="Responsibity" >
                                    </div>


                                    <div class="col-md-12">
                                        <h3>Work Experience</h3>

                                    </div>


                                    <div class="col-md-12">
                                        <input id="job_title" class="job_title" type="text" name="work_xp2" placeholder="Job Title" >
                                    </div>


                                    <div class="col-md-12">
                                        <input id="job_description" class="job_description" type="text" name="work_xp2_description" placeholder="Job Description">
                                    </div>


                                    <div class="col-md-12">
                                        <h3 style="font-size: x-large;">Responsibities</h3>

                                    </div>

                                    <div class="col-md-12">
                                        <input id="responsibity_one" class="responsibity" type="text" name="work_xp2_res1" placeholder="Responsibity">
                                    </div>


                                    <div class="col-md-12">
                                        <input id="responsibity_two" class="responsibity" type="text" name="work_xp2_res2" placeholder="Responsibity">
                                    </div>


                                    <div class="col-md-12">
                                        <input id="responsibity_three" class="responsibity" type="text" name="work_xp2_res3" placeholder="Responsibity">
                                    </div>


                                    <div class="col-md-12">
                                        <input id="responsibity_four" class="responsibity" type="text" name="work_xp2_res4" placeholder="Responsibity">
                                    </div>



                                    <div class="col-md-12">

                                        <h4>NON-RETATED REFEREES</h4>

                                    </div>


                                    <div class="col-md-6">
                                        <input id="non_refree1_name" class="non_refree1_name" type="text" name="non_refree1_name" placeholder="Non Related Referee1 Name" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="non_refree1_post" class="non_refree1_post" type="text" name="non_refree1_post" placeholder="Non Related Referee1 Post" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="non_refree1_workplace" class="non_refree1_workplace" type="text" name="non_refree1_workplace" placeholder="Non Related Referee1 working Place" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="non_refree1_tel" class="non_refree1_tel" type="text" name="non_refree1_tel" placeholder="Contact Number of Referee1" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="non_refree2_name" class="non_refree2_name" type="text" name="non_refree2_name" placeholder="Non Related Referee2 Name">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="non_refree2_post" class="non_refree2_post" type="text" name="non_refree2_post" placeholder="Non Related Referee2 Post">
                                    </div>

                                     <div class="col-md-6">
                                        <input id="non_refree2_workplace" class="non_refree2_workplace" type="text" name="non_refree2_workplace" placeholder="Non Related Referee2 working Place">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="non_refree2_tel" class="non_refree2_tel" type="text" name="non_refree2_tel" placeholder="Contact Number of Referee2">
                                    </div>

                                    <div class="clearfix"></div>

                                    <div class="col-md-12 form-btn-submit">
                                        <input id="contact-button" class="button button-full contact-submit" name="contact-submit" value="Submit" type="submit">
                                    </div>

                                </form>
                            </div>
                            <!-- End Contact Form -->

                        </div> <!-- .row -->
                    </div> <!-- .container -->
                </section>
                <!-- End Contact us -->

                <!-- Start Newsletter -->
            
            
            

            
            
            
            

            
            
            
            
            
            
            
            
            
            

            
            
            
            <!-- End Newsletter -->

            </main>
        </div> <!-- #primary -->
    </div> <!-- #content -->

    <!-- Start Footer -->






























































<!-- End Footer -->

</div> <!-- #page -->

<!-- Include JS -->
<script src="<?php echo e(URL('home_assest/jquery.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/bootstrap-hover-dropdown.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/parallax.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/aos.js')); ?>"></script>

<script src="<?php echo e(URL('init.js')); ?>"></script>




<![endif]-->

<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','../../../../www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-80974374-1', 'auto');
    ga('send', 'pageview');

</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\cvtemp\resources\views/form4.blade.php ENDPATH**/ ?>