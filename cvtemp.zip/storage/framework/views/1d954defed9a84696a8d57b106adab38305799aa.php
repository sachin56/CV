<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e($user_email); ?></title>



    <style>
        div.a {
            text-indent: 20px;
        }
    </style>
</head>

<body>

<div style= "">
    <h1 style="color:#468785"><?php echo e($data->full_name); ?></h1>
    <hr>
</div>
<div style ="">
    <p><?php echo e($data->address); ?></p> <p><?php echo e($data->contact_no1); ?></p>
    <p>Home:<?php echo e($data->contact_no2); ?>| <?php echo e($data->email); ?></p>


</div>
<div style ="">
    <h3 style="color:#468785">Objective</h3>

    <label><?php echo e($data->objective); ?> </label>
</div>

<div style="">
    <h3 style="color:#468785">Education</h3>
    <P><b>G.C.E ORDINARY LEVEL |2011| VISAKHA VIDYALAYA </b><P>
    <div  class="a">
        <table style="align:center" width="300px">

            <tr>
                <td><?php echo e($data->subject1); ?></td>
                <td><?php echo e($data->result1); ?></td>

            </tr>
            <tr>
                <td><?php echo e($data->subject2); ?></td>
                <td><?php echo e($data->result2); ?></td>

            </tr>
            <tr>
                <td><?php echo e($data->subject3); ?></td>
                <td><?php echo e($data->result3); ?></td>

            </tr>
            <tr>
                <td><?php echo e($data->subject4); ?></td>
                <td><?php echo e($data->result4); ?></td>

            </tr>
            <tr>
                <td><?php echo e($data->subject5); ?></td>
                <td><?php echo e($data->result5); ?></td>

            </tr>
            <tr>
                <td><?php echo e($data->subject6); ?></td>
                <td><?php echo e($data->result6); ?></td>

            </tr>
            <tr>
                <td><?php echo e($data->subject7); ?></td>
                <td><?php echo e($data->result7); ?></td>

            </tr>
            <tr>
                <td><?php echo e($data->subject8); ?></td>
                <td><?php echo e($data->result8); ?></td>

            </tr>
            <tr>
                <td><?php echo e($data->subject9); ?></td>
                <td><?php echo e($data->result9); ?></td>

            </tr>

        </table></div><br>
    <P><b>G.C.E ADVANCED LEVEL |2014| VISAKHA VIDYALAYA </b><P>
    <div  class="a">
        <table style="align:center">
            <tr>
                <td><?php echo e($data->al_subject1); ?> </td>
                <td><?php echo e($data->al_result1); ?></td>

            </tr>
            <tr>
                <td><?php echo e($data->al_subject2); ?></td>
                <td><?php echo e($data->al_result2); ?></td>

            </tr>
            <tr>
                <td><?php echo e($data->al_subject3); ?> </td>
                <td><?php echo e($data->al_result3); ?></td>

            </tr>
            <tr>
                <td><?php echo e($data->al_subject4); ?></td>
                <td><?php echo e($data->al_result4); ?></td>

            </tr>
        </table></div>
</div>
<div style="">
    <h3 style="color:#468785">Higher Education</h3>
    <div class="a">
        <p><?php echo e($data->higher_edu); ?></p>
    </div>
    <div class="page_break" style="page-break-before: always;"></div>
    <h3 style="color:#468785">Other Achievements</h3>
    <div class="a">
        <table style="align:center">
            <tr>
                <td><?php echo e($data->other1); ?></td>
            </tr>
            <tr>
                <td><?php echo e($data->other2); ?> </td>
            </tr>
            <tr>
                <td><?php echo e($data->other3); ?></td>
            </tr>
        </table>
    </div>
</div>
<div style="">
    <h3 style="color:#468785">Work Experience</h3>
    <div class="a">
        <p><li><b><?php echo e($data->work_xp1); ?></b></li><p>
        <p><?php echo e($data->work_xp1_description); ?></p>
        <br>

        <div class="a">Job responsibilities contained –</div>
        <ul>
            <li><table style="align:center">
                    <tr>
                        <td><?php echo e($data->work_xp1_res1); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->work_xp1_res2); ?> </td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->work_xp1_res3); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->work_xp1_res3); ?></td>
                    </tr>
                </table>
            </li>


        </ul>

    </div>
    <div>
        <p><li><b><?php echo e($data->work_xp2); ?></b></li><p>
        <p><?php echo e($data->work_xp2_description); ?></p>
        <br>

        <div class="a">Job responsibilities contained –</div>
        <ul>
            <li><table style="align:center">
                    <tr>
                        <td><?php echo e($data->work_xp2_res1); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->work_xp2_res2); ?> </td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->work_xp2_res3); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e($data->work_xp2_res3); ?></td>
                    </tr>
                </table>
            </li>


        </ul>

        <!-- <p><li><b>CO-ORDINATING EXECUTIVE | OVERSEAS REALTY CEYLON LIMITED</b></li><p>
        <p><li><b>CO-ORDINATING EXECUTIVE | OVERSEAS REALTY CEYLON LIMITED</b></li><p></div>	 -->
        <div>
            <h3 style="color:#468785;padding: 0;">Non Related Referees</h3>

            <table style="height: 110px" width="670px"border="0">
                <tr>
                    <td>
                        <?php echo e($data->non_refree1_name); ?>.,<br>
                        <?php echo e($data->non_refree1_post); ?><br>
                        <?php echo e($data->non_refree1_workplace); ?><br>
                        <?php echo e($data->non_refree1_tel); ?><br>

                    </td>
                    <td>
                        <?php echo e($data->non_refree2_name); ?>.,<br>
                        <?php echo e($data->non_refree2_post); ?><br>
                        <?php echo e($data->non_refree2_workplace); ?><br>
                        <?php echo e($data->non_refree2_tel); ?><br>
                    </td>
                </tr>
            </table>

        </div>

    </div>

    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cvtemp\resources\views/pdf/form4_pdf.blade.php ENDPATH**/ ?>