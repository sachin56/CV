<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.harbourthemes.com/demo/dot/blocks/forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 02 Jul 2020 17:42:56 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <title>CVTemp</title>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Favicons for Desktop, iOS and android -->
    <link rel="icon" type="image/png" sizes="32x32" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/favicon-16x16.png">
    <link rel="apple-touch-icon" sizes="180x180" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="192x192" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/android-chrome-192x192.png">
    <link rel="mask-icon" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/safari-pinned-tab.svg" color="#5bbad5">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,900" rel="stylesheet">

    <link href="<?php echo e(URL('home_assest/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/simple-line-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/magnific-popup.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/owl.theme.default.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/aos.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/color-switcher.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL('home_assest/color-1.css')); ?>" rel="stylesheet">

    <!--[if IE]>
    <link href="../assets/css/ie.css" rel="stylesheet">
    <![endif]-->

    <script src="<?php echo e(URL('home_assest/modernizr.js')); ?>"></script>

    <style>

        .uploadImg{
            display: inline-block;
            vertical-align: middle;
            margin: 0 0 1rem 0;
            font-family: inherit;
            padding: 0.85em 1em;
            -webkit-appearance: none;
            border: 1px solid transparent;
            border-radius: 0;
            -webkit-transition: background-color 0.25s ease-out, color 0.25s ease-out;
            transition: background-color 0.25s ease-out, color 0.25s ease-out;
            font-size: 0.9rem;
            line-height: 1;
            text-align: center;
            cursor: pointer;
            background-color: #38ceea;
            color: #fefefe;
        }

        .show-for-sr {
            position: absolute !important;
            width: 1px;
            height: 1px;
            padding: 0;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            -webkit-clip-path: inset(50%);
            clip-path: inset(50%);
            border: 0;
        }

    </style>

</head>

<body>

<div id="page" class="site"> <div class="baseline-grid1"></div>

    <!-- Start Header -->
    <header id="masthead" class="site-header">

        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </header>
    <!-- End Header -->

    <div id="content" class="site-content">
        <div id="primary" class="content-area">
            <main id="main" class="site-main">

                <!-- Start Contact us -->
                <section id="contact-us---1" class="container-fluid section-block contact-form-section">
                    <div class="form-bg"></div> <!-- Background image -->
                    <div class="overlay"></div>	<!-- Overlay -->
                    <div class="container">
                        <div class="row">

                            <!-- Start Contact Form -->
                            <div class="col-md-10 center-form border-box" style="margin-top: 20px;padding-bottom: 100px;">
                                <form method="post" class="contact-form" id="FormFive" enctype="multipart/form-data">

                                    
                                    
                                    

                                    <div class="col-md-12">
                                        <label for="uploadImg" class="uploadImg">Upload Image</label>
                                        <input type="file" id="uploadImg" class="show-for-sr" name="main_image" required>
                                        <label id="image-name" class="label-hide"></label>
                                        <br><br>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="contact-f-name" class="contact-f-name" type="text" name="full_name" placeholder="Full Name" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="address1" class="address1" type="text" name="address1" placeholder="Address line 01" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="address2" class="address2" type="text" name="address2" placeholder="Address line 02" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="address3" class="address3" type="text" name="contact1" placeholder="Contact No 1" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="address3" class="address3" type="text" name="contact2" placeholder="Contact No 2">
                                    </div>

                                    <div class="col-md-12">
                                        <input id="contact-email" class="contact-email" type="email" name="email" placeholder="Email" required>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="contact-Enter Details" class="contact-Enter Details" type="text" name="objective" placeholder="Careere Objective" required>
                                    </div>

                                    <div class="col-md-12">
                                        <h3 >Academic Qualification</h3>
                                    </div>


                                    <div class="col-md-12">
                                        <input id="contact-Qulification One" class="contact-Qulification One" type="text" name="a_qualify1" placeholder="Qulification One" required>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="contact-Qulification Two" class="contact-Qulification Two" type="text" name="a_qualify2" placeholder="Qulification Two" >
                                    </div>

                                    <div class="col-md-12">
                                        <input id="contact-Qulification Three" class="contact-Qulification Three" type="text" name="a_qualify3" placeholder="Qulification Three" >
                                    </div>

                                    <div class="col-md-12">
                                        <input id="contact-Qulification Four" class="contact-Qulification Four" type="text" name="a_qualify4" placeholder="Qulification Four" >
                                    </div>

                                    <div class="col-md-12">
                                        <input id="contact-Qulification Five" class="contact-Qulification Five" type="text" name="a_qualify5" placeholder="Qulification Five" >
                                    </div>

                                    <div class="col-md-12">
                                        <input id="contact-Qulification Five" class="contact-Qulification Five" type="text" name="a_qualify6" placeholder="Qulification Six" >
                                    </div>


                                    <div class="col-md-12">
                                        <h3>Skills & Abilities</h3>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="contact-Enter Details" class="contact-Enter Details" type="text" name="skill_ability" placeholder="Enter Details" required>
                                    </div>
                                    <div class="col-md-12">
                                        <h3>Education Qulifications</h3>
                                    </div>

                                    <div class="col-md-12">
                                        <h3>Edexcel Ordinary Level Examination</h3>
                                    </div>
                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject1" placeholder="Subject1" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results1" placeholder="Results1" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject2" placeholder="Subject2" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results2" placeholder="Results2" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject3" placeholder="Subject3">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results3" placeholder="Results3">
                                    </div>
                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject4" placeholder="Subject4" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results4" placeholder="Results4">
                                    </div>
                                    <div class="col-md-6">
                                        <input id="Subject" class="Subject" type="text" name="subject5" placeholder="Subject5" >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results5" placeholder="Results5">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="results6" placeholder="Results6" >
                                    </div>

                                    <div class="col-md-12">
                                        <h3>G.C.E. Ordinary Level Examination</h3>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="ol_subject1" placeholder="Subject 1" required>
                                    </div>
                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="ol_result1" placeholder="Results 1" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="ol_subject2" placeholder="Subject 2" required>
                                    </div>
                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="ol_result2" placeholder="Results 2" required>
                                    </div>

                                    <div class="col-md-12">
                                        <h3>Edexcel G.C.E. Advanced Level Examination</h3>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="al_subject1" placeholder="Subject " required>
                                    </div>
                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="al_result1" placeholder="Results " required>
                                    </div>
                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="al_subject2" placeholder="Subject " required>
                                    </div>
                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="al_result2" placeholder="Results " required>
                                    </div>

                                    <div class="col-md-12">
                                        <h3>LEADERSHIPS:</h3>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="lead1" placeholder="Leaderships 1" required>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="lead2" placeholder="Leaderships 2" >
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="lead3" placeholder="Leaderships 3" >
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="lead4" placeholder="Leaderships 4" >
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="lead5" placeholder="Leaderships 5">
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="lead6" placeholder="Leaderships 6">
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="lead7" placeholder="Leaderships 7" >
                                    </div>

                                    <div class="col-md-12">
                                        <h3>GAMES AND ATHLETICS:</h3>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="game1" placeholder="Games And Athletics 1" required>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="game2" placeholder="Games And Athletics 2" >
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="game3" placeholder="Games And Athletics 3" >
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="game4" placeholder="Games And Athletics 4" >
                                    </div>

                                    <div class="col-md-12">
                                        <h3>SKILLS AND COMPETENCIES:</h3>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="skill1" placeholder="Skills And Competencies: 1" required>
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="skill2" placeholder="Skills And Competencies: 2" >
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="skill3" placeholder="Skills And Competencies: 3" >
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="skill4" placeholder="Skills And Competencies: 4">
                                    </div>
                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="skill5" placeholder="Skills And Competencies: 5" >
                                    </div>

                                    <div class="col-md-12">
                                        <input id="Results" class="Results" type="text" name="skill6" placeholder="Skills And Competencies: 6" >
                                    </div>
                                    <div class="col-md-12">
                                        <h3>PERSONAL DETAILS:</h3>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="dob" placeholder="Date of Birth" required>
                                    </div>
                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="m_status" placeholder="Martial Status" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="nationality" placeholder="Nationality" required>
                                    </div>
                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="nic" placeholder="NIC" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="school" placeholder="School Attended" required>
                                    </div>

                                    <div class="col-md-12">
                                        <h3>NON-RELATED REFEREES:</h3>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="non_refree1_name" placeholder="Non-Related Refree1 Name " required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="non_refree1_post" placeholder="Non-Related Refree1 Post" required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="non_refree1_workplace" placeholder="Non-Related Refree1 Workplace " required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="non_refree1_tel" placeholder="Non-Related Refree1 Tel " required>
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="non_refree2_name" placeholder="Non-Related Refree2 Name " >
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="non_refree2_post" placeholder="Non-Related Refree2 Post">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="non_refree2_workplace" placeholder="Non-Related Refree2 Workplace ">
                                    </div>

                                    <div class="col-md-6">
                                        <input id="Results" class="Results" type="text" name="non_refree2_tel" placeholder="Non-Related Refree2 Tel ">
                                    </div>


                                    <div class="clearfix"></div>

                                    <div class="col-md-12 form-btn-submit">
                                        <input id="contact-button" class="button button-full contact-submit" name="contact-submit" value="Submit" type="submit">
                                    </div>

                                </form>
                            </div>
                            <!-- End Contact Form -->

                        </div> <!-- .row -->
                    </div> <!-- .container -->
                </section>
                <!-- End Contact us -->

                <!-- Start Newsletter -->
            
            
            

            
            
            
            

            
            
            
            
            
            
            
            
            
            

            
            
            
            <!-- End Newsletter -->

            </main>
        </div> <!-- #primary -->
    </div> <!-- #content -->

    <!-- Start Footer -->






























































<!-- End Footer -->

</div> <!-- #page -->

<!-- Include JS -->
<script src="<?php echo e(URL('home_assest/jquery.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/bootstrap-hover-dropdown.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/parallax.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/aos.js')); ?>"></script>

<script src="<?php echo e(URL('init.js')); ?>"></script>




<![endif]-->

<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','../../../../www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-80974374-1', 'auto');
    ga('send', 'pageview');

    $("#uploadImg").change(function(e) {

        let lbl = document.getElementById('image-name');
        var fileName = e. target. files[0]. name;
        lbl.innerText = fileName;

    });

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('#FormFive').on('submit', function(event) {
        event.preventDefault();

        $.ajax({
            url: "<?php echo e(url('/form5/submit')); ?>",
            method: "POST",
            data: new FormData(this),
            dataType: 'JSON',
            contentType: false,
            cache: false,
            processData: false,
            success: function(response) {
                console.log(response.message);
                if(response.success) {

                    window.location.href = "<?php echo e(url('/download/pdf')); ?>/"+response.message;
                } else {
                    if(response.message === "") {
                        response.message = "Error Occured while updating profile. Please try again!";
                    }
                }
            }
        });
    });

</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\cvtemp\resources\views/form5.blade.php ENDPATH**/ ?>