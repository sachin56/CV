<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
		<title>CV Temp</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">

		<!-- Favicons for Desktop, iOS and android -->
		<link rel="icon" type="image/png" sizes="32x32" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="16x16" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/favicon-16x16.png">
		<link rel="apple-touch-icon" sizes="180x180" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/apple-touch-icon.png">
		<link rel="icon" type="image/png" sizes="192x192" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/android-chrome-192x192.png">
		<link rel="mask-icon" href="http://demo.harbourthemes.com/demo/dot/assets/images/favicons/safari-pinned-tab.svg" color="#5bbad5">

		<link href="https://fonts.googleapis.com/css?family=Lato:400,700,900" rel="stylesheet">

		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo e(URL('home_assest/bootstrap.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(URL('home_assest/font-awesome.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(URL('home_assest/simple-line-icons.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(URL('home_assest/magnific-popup.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(URL('home_assest/owl.carousel.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(URL('home_assest/owl.theme.default.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(URL('home_assest/aos.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(URL('home_assest/style.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(URL('home_assest/color-switcher.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(URL('home_assest/color-1.css')); ?>" rel="stylesheet">


    <link href="<?php echo e(URL('/bootstrap-modal-carousel.css')); ?>" rel="stylesheet" />






		<script src="<?php echo e(URL('home_assest/modernizr.js')); ?>"></script>






<style>

    .close {
        margin-top: -8px !important;
    }

</style>

	</head>

<body>

	<!-- Start Preloader -->
	<div id="page-preloader">
		<div class="preloader">
			<span class="circle"></span>
		</div>
	</div>
	<!-- End Preloader -->

<div id="page" class="site">

	<!-- Start Header -->
	<header id="masthead" class="site-header">

	<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





















	</header>
	<!-- End Header -->

	<div id="content" class="site-content">
		<div id="primary" class="content-area">
			<main id="main" class="site-main">

















































				<!-- Start About Block 3 -->
































				<!-- End About Block 3 -->

				<!-- Start About Block 4 -->
































				<!-- End About Block 4 -->

				<!-- Start Features 3 -->







































				<!-- End Features 3 -->

				<!-- Start How to use 2 -->


































				<!-- End How to use 2 -->

				<!-- Start Prices 2 -->













































































































				<!-- End Prices 2 -->

				<!-- Start FAQ 1 -->








































				<!-- End FAQ 1 -->

				<!-- Start Download 2 -->



























				<!-- End Download 2 -->

				<!-- Start Reviews 1 -->



















































































































































































				<!-- Start Integration -->

















































































































































































































































































				<!-- Start Team 2 -->
				<section id="team---2" class="container-fluid section-block team-2">
					<div class="container" style="margin-top: 100px;">
						<div class="row">






							<!-- Member 1 -->
							<div class="col-md-3 col-sm-6 member-block">
								<div class="border-box">

									<div class="member-photo">
										<img src="<?php echo e(URL('templates/1.JPG')); ?>" style="height: 330px;" alt="member">
									</div> <!-- .member-photo -->

									<div class="member-content">

                                        <button class="btn btn-success btn-xs" id="form_used" data-toggle="modal" data-book-id="1" href="#my_modal">Template 1</button>
									</div>

								</div> <!-- .border-box -->
							</div>
                            <!-- .member-block -->

							<!-- Member 2 -->
							<div class="col-md-3 col-sm-6 member-block">
								<div class="border-box">

									<div class="member-photo">
										<img src="<?php echo e(URL('templates/2.JPG')); ?>" style="height: 330px;" alt="member">
									</div> <!-- .member-photo -->

									<div class="member-content">

                                        <button class="btn btn-success btn-xs" id="form_used" data-toggle="modal" data-book-id="2" href="#my_modal">Template 2</button>
									</div>

								</div> <!-- .border-box -->
							</div> <!-- .member-block -->

							<!-- Member 3 -->
							<div class="col-md-3 col-sm-6 member-block">
								<div class="border-box">

									<div class="member-photo">
										<img src="<?php echo e(URL('templates/3.JPG')); ?>" style="height: 330px;" alt="member">
									</div> <!-- .member-photo -->

									<div class="member-content">

                                        <button class="btn btn-success btn-xs" id="form_used" data-toggle="modal" data-book-id="3" href="#my_modal">Template 3</button>
									</div>

								</div> <!-- .border-box -->
							</div> <!-- .member-block -->

							<!-- Member 4 -->
							<div class="col-md-3 col-sm-6 member-block">
								<div class="border-box">

									<div class="member-photo">
										<img src="<?php echo e(URL('templates/4.JPG')); ?>" style="height: 330px;" alt="member">
									</div> <!-- .member-photo -->

									<div class="member-content">

                                        <button class="btn btn-success btn-xs" id="form_used" data-toggle="modal" data-book-id="4" href="#my_modal">Template 4</button>
									</div>

								</div> <!-- .border-box -->
							</div> <!-- .member-block -->

						</div> <!-- .row -->

                        <div class="row">
                            <div class="col-md-3 col-sm-6 member-block">
                                <div class="border-box">

                                    <div class="member-photo">
                                        <img src="<?php echo e(URL('templates/5.JPG')); ?>" style="height: 330px;" alt="member">
                                    </div> <!-- .member-photo -->

                                    <div class="member-content">
                                        
                                        <button class="btn btn-success btn-xs" id="form_used" data-toggle="modal" data-book-id="5" href="#my_modal">Template 5</button>
                                    </div>

                                </div> <!-- .border-box -->
                            </div>
                            <div class="col-md-3 col-sm-6 member-block">
                                <div class="border-box">

                                    <div class="member-photo">
                                        <img src="<?php echo e(URL('templates/6.JPG')); ?>" style="height: 330px;" alt="member">
                                    </div> <!-- .member-photo -->

                                    <div class="member-content">
                                        
                                        <button class="btn btn-success btn-xs" id="form_used" data-toggle="modal" data-book-id="6" href="#my_modal">Template 6</button>
                                    </div>

                                </div> <!-- .border-box -->
                            </div>
                            <div class="col-md-3 col-sm-6 member-block">
                                <div class="border-box">

                                    <div class="member-photo">
                                        <img src="<?php echo e(URL('templates/7.JPG')); ?>"  style="height: 330px;" alt="member">
                                    </div> <!-- .member-photo -->

                                    <div class="member-content">
                                        
                                        <button class="btn btn-success btn-xs" id="form_used" data-toggle="modal" data-book-id="7" href="#my_modal">Template 7</button>
                                    </div>

                                </div> <!-- .border-box -->
                            </div>
                            <div class="col-md-3 col-sm-6 member-block">
                                <div class="border-box">

                                    <div class="member-photo">
                                        <img src="<?php echo e(URL('templates/8.JPG')); ?>" style="height: 330px;" alt="member">
                                    </div> <!-- .member-photo -->

                                    <div class="member-content">
                                        
                                        <button class="btn btn-success btn-xs" id="form_used" data-toggle="modal" data-book-id="8" href="#my_modal">Template 8</button>
                                    </div>

                                </div> <!-- .border-box -->
                            </div>
                            <div class="col-md-3 col-sm-6 member-block">
                                <div class="border-box">

                                    <div class="member-photo">
                                        <img src="<?php echo e(URL('templates/9.JPG')); ?>" style="height: 330px;" alt="member">
                                    </div> <!-- .member-photo -->

                                    <div class="member-content">
                                        
                                        <button class="btn btn-success btn-xs" id="form_used" data-toggle="modal" data-book-id="9" href="#my_modal">Template 9</button>
                                    </div>

                                </div> <!-- .border-box -->
                            </div>
                        </div>

                    </div> <!-- .container -->
				</section>
				<!-- End Team 2 -->



















































			</main>
		</div> <!-- #primary -->
	</div> <!-- #content -->


































































</div> <!-- #page -->

    <!-- Trigger the modal with a button -->



    <!-- Modal -->

















































































    <!-- Modal -->



    <div class="modal" id="my_modal">
        <div class="modal-dialog">
            <div class="modal-content" id="content_show">


            </div>
        </div>
    </div>




<!-- Include JS -->
<script src="<?php echo e(URL('home_assest/jquery.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/bootstrap-hover-dropdown.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/parallax.js')); ?>"></script>
<script src="<?php echo e(URL('home_assest/aos.js')); ?>"></script>
    <script src="<?php echo e(URL('/bootstrap-modal-carousel.js')); ?>"></script>

<script src="<?php echo e(URL('init.js')); ?>"></script>






<script>
  // (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  // (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  // m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  // })(window,document,'script','../../../www.google-analytics.com/analytics.js','ga');
  //
  // ga('create', 'UA-80974374-1', 'auto');
  // ga('send', 'pageview');

  $('#my_modal').on('show.bs.modal', function(e) {
      var tempId = $(e.relatedTarget).data('book-id');
      $(e.currentTarget).find('input[name="bookId"]').val(tempId);
      console.log(tempId);

      if(tempId === 1) {

          var content1 = ' <div class="modal-header">\n' +
              '                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>\n' +
              '                </div>' +
              '<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">\n' +
              '\n' +
              '\n' +
              '\n' +
              '                    <!-- Wrapper for slides -->\n' +
              '                    <div class="carousel-inner">\n' +
              '                        <div class="item active">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/1.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/1.1.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/1.3.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                    </div>\n' +
              '\n' +
              '                    <!-- Controls -->\n' +
              '                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">\n' +
              '                        <span class="glyphicon glyphicon-chevron-left"></span>\n' +
              '                    </a>\n' +
              '                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">\n' +
              '                        <span class="glyphicon glyphicon-chevron-right"></span>\n' +
              '                    </a>\n' +
              '                </div>\n' +
              '                <div class="modal-footer">\n' +
              '                    <div class="text-center"><button type="button" class="btn btn-default" onclick="SelectTemplate(1)">Select Template</button></div>\n' +
              '                </div>';

          $('#content_show').html(content1);
      }
      else if(tempId === 2) {

          var content2 = ' <div class="modal-header">\n' +
              '                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>\n' +
              '                </div>' +
              '<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">\n' +
              '\n' +
              '\n' +
              '\n' +
              '                    <!-- Wrapper for slides -->\n' +
              '                    <div class="carousel-inner">\n' +
              '                        <div class="item active">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/2.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/2.1.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                    </div>\n' +
              '\n' +
              '                    <!-- Controls -->\n' +
              '                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">\n' +
              '                        <span class="glyphicon glyphicon-chevron-left"></span>\n' +
              '                    </a>\n' +
              '                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">\n' +
              '                        <span class="glyphicon glyphicon-chevron-right"></span>\n' +
              '                    </a>\n' +
              '                </div>\n' +
              '                <div class="modal-footer">\n' +
              '                    <div class="text-center"><button type="button" class="btn btn-default" onclick="SelectTemplate(2)">Select Template</button></div>\n' +
              '                </div>';

          $('#content_show').html(content2);
      }
      else if(tempId === 3) {

          var content3 = ' <div class="modal-header">\n' +
              '                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>\n' +
              '                </div>' +
              '<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">\n' +
              '\n' +
              '\n' +
              '\n' +
              '                    <!-- Wrapper for slides -->\n' +
              '                    <div class="carousel-inner">\n' +
              '                        <div class="item active">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/3.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/3.1.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/3.2.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                    </div>\n' +
              '\n' +
              '                    <!-- Controls -->\n' +
              '                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">\n' +
              '                        <span class="glyphicon glyphicon-chevron-left"></span>\n' +
              '                    </a>\n' +
              '                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">\n' +
              '                        <span class="glyphicon glyphicon-chevron-right"></span>\n' +
              '                    </a>\n' +
              '                </div>\n' +
              '                <div class="modal-footer">\n' +
              '                    <div class="text-center"><button type="button" class="btn btn-default" onclick="SelectTemplate(3)">Select Template</button></div>\n' +
              '                </div>';

          $('#content_show').html(content3);
      }
      else if(tempId === 4) {

          var content4 = ' <div class="modal-header">\n' +
              '                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>\n' +
              '                </div>' +
              '<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">\n' +
              '\n' +
              '\n' +
              '\n' +
              '                    <!-- Wrapper for slides -->\n' +
              '                    <div class="carousel-inner">\n' +
              '                        <div class="item active">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/4.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/4.1.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/4.2.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                    </div>\n' +
              '\n' +
              '                    <!-- Controls -->\n' +
              '                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">\n' +
              '                        <span class="glyphicon glyphicon-chevron-left"></span>\n' +
              '                    </a>\n' +
              '                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">\n' +
              '                        <span class="glyphicon glyphicon-chevron-right"></span>\n' +
              '                    </a>\n' +
              '                </div>\n' +
              '                <div class="modal-footer">\n' +
              '                    <div class="text-center"><button type="button" class="btn btn-default" onclick="SelectTemplate(4)">Select Template</button></div>\n' +
              '                </div>';

          $('#content_show').html(content4);
      }
      else if(tempId === 5) {

          var content5 = ' <div class="modal-header">\n' +
              '                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>\n' +
              '                </div>' +
              '<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">\n' +
              '\n' +
              '\n' +
              '\n' +
              '                    <!-- Wrapper for slides -->\n' +
              '                    <div class="carousel-inner">\n' +
              '                        <div class="item active">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/5.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/5.1.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/5.2.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/5.3.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                    </div>\n' +
              '\n' +
              '                    <!-- Controls -->\n' +
              '                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">\n' +
              '                        <span class="glyphicon glyphicon-chevron-left"></span>\n' +
              '                    </a>\n' +
              '                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">\n' +
              '                        <span class="glyphicon glyphicon-chevron-right"></span>\n' +
              '                    </a>\n' +
              '                </div>\n' +
              '                <div class="modal-footer">\n' +
              '                    <div class="text-center"><button type="button" class="btn btn-default" onclick="SelectTemplate(5)">Select Template</button></div>\n' +
              '                </div>';

          $('#content_show').html(content5);
      }
      else if(tempId === 6) {

          var content6 = ' <div class="modal-header">\n' +
              '                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>\n' +
              '                </div>' +
              '<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">\n' +
              '\n' +
              '\n' +
              '\n' +
              '                    <!-- Wrapper for slides -->\n' +
              '                    <div class="carousel-inner">\n' +
              '                        <div class="item active">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/6.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/6.1.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/6.3.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/6.4.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                    </div>\n' +
              '\n' +
              '                    <!-- Controls -->\n' +
              '                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">\n' +
              '                        <span class="glyphicon glyphicon-chevron-left"></span>\n' +
              '                    </a>\n' +
              '                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">\n' +
              '                        <span class="glyphicon glyphicon-chevron-right"></span>\n' +
              '                    </a>\n' +
              '                </div>\n' +
              '                <div class="modal-footer">\n' +
              '                    <div class="text-center"><button type="button" class="btn btn-default" onclick="SelectTemplate(6)">Select Template</button></div>\n' +
              '                </div>';

          $('#content_show').html(content6);
      }
      else if(tempId === 7) {

          var content7 = ' <div class="modal-header">\n' +
              '                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>\n' +
              '                </div>' +
              '<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">\n' +
              '\n' +
              '\n' +
              '\n' +
              '                    <!-- Wrapper for slides -->\n' +
              '                    <div class="carousel-inner">\n' +
              '                        <div class="item active">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/7.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/7.2.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/7.3.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                    </div>\n' +
              '\n' +
              '                    <!-- Controls -->\n' +
              '                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">\n' +
              '                        <span class="glyphicon glyphicon-chevron-left"></span>\n' +
              '                    </a>\n' +
              '                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">\n' +
              '                        <span class="glyphicon glyphicon-chevron-right"></span>\n' +
              '                    </a>\n' +
              '                </div>\n' +
              '                <div class="modal-footer">\n' +
              '                    <div class="text-center"><button type="button" class="btn btn-default" onclick="SelectTemplate(7)">Select Template</button></div>\n' +
              '                </div>';

          $('#content_show').html(content7);
      }
      else if(tempId === 8) {

          var content8 = ' <div class="modal-header">\n' +
              '                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>\n' +
              '                </div>' +
              '<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">\n' +
              '\n' +
              '\n' +
              '\n' +
              '                    <!-- Wrapper for slides -->\n' +
              '                    <div class="carousel-inner">\n' +
              '                        <div class="item active">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/8.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/8.1.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/8.2.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                    </div>\n' +
              '\n' +
              '                    <!-- Controls -->\n' +
              '                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">\n' +
              '                        <span class="glyphicon glyphicon-chevron-left"></span>\n' +
              '                    </a>\n' +
              '                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">\n' +
              '                        <span class="glyphicon glyphicon-chevron-right"></span>\n' +
              '                    </a>\n' +
              '                </div>\n' +
              '                <div class="modal-footer">\n' +
              '                    <div class="text-center"><button type="button" class="btn btn-default" onclick="SelectTemplate(8)">Select Template</button></div>\n' +
              '                </div>';

          $('#content_show').html(content8);
      }
      else if(tempId === 9) {

          var content9 = ' <div class="modal-header">\n' +
              '                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>\n' +
              '                </div>' +
              '<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">\n' +
              '\n' +
              '\n' +
              '\n' +
              '                    <!-- Wrapper for slides -->\n' +
              '                    <div class="carousel-inner">\n' +
              '                        <div class="item active">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/9.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/9.1.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                        <div class="item">\n' +
              '                            <img class="img-responsive" src="<?php echo e(URL('templates/ss/9.2.JPG')); ?>" alt="...">\n' +
              '                        </div>\n' +
              '                    </div>\n' +
              '\n' +
              '                    <!-- Controls -->\n' +
              '                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">\n' +
              '                        <span class="glyphicon glyphicon-chevron-left"></span>\n' +
              '                    </a>\n' +
              '                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">\n' +
              '                        <span class="glyphicon glyphicon-chevron-right"></span>\n' +
              '                    </a>\n' +
              '                </div>\n' +
              '                <div class="modal-footer">\n' +
              '                    <div class="text-center"><button type="button" class="btn btn-default" onclick="SelectTemplate(9)">Select Template</button></div>\n' +
              '                </div>';

          $('#content_show').html(content9);
      }





  });

function SelectTemplate(id) {


    window.location.href = "<?php echo e(url('/form_details/')); ?>/"+id;

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}


</script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\cvtemp\resources\views/index.blade.php ENDPATH**/ ?>