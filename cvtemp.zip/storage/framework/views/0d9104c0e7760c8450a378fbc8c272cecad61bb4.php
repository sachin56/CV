<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo e($user_email); ?></title>
</head>

<body>
<table style="width: 670px;" align="center">
    <tr style="height: 120px;">
        <td style="text-align: center">
            <b><?php echo e($data->full_name); ?></b><br>
            <b><?php echo e($data->address1); ?>,</b><br>
            <b><?php echo e($data->address2); ?>,</b><br>
            <b><?php echo e($data->address3); ?>.</b><br>
            <b>Tel: <?php echo e($data->contact1); ?>, <?php echo e($data->contact2); ?></b><br>
            <b>Email address: <?php echo e($data->email); ?></b><br><br>
        </td>
        <td style="width: 120px;">
            <img src="<?php echo e(URL('storage/forms/form1')); ?>/<?php echo e($data->main_image); ?>" alt="photo" height="120" width="120">
        </td>
    </tr><br><br>


</table>

<table style="width: 670px;" align="center">
    <tr>
        <td><b>PERSONAL PROFILE</b><br></td>
    </tr>
    <tr>
        <td>
            <p>
                <?php echo e($data->personal_profile); ?>

            </p>
        </td>
    </tr>
    <tr>
        <td style="height: 50px">
            <label><b>Date of Birth</b>:<?php echo e($data->personal_profile); ?></label><br>
            <label><b>Civil Status</b>:<?php echo e($data->civil_status); ?></label><br>
            <label><b>Sex</b>:<?php echo e($data->sex); ?></label><br>
            <label><b>Religion</b>:<?php echo e($data->religion); ?></label><br>
            <label><b>NIC Number</b>:<?php echo e($data->nic); ?></label><br>
        </td>
    </tr>
</table>

<table style="width: 670px;" align="center">
    <tr>
        <td style="height: 50px">
            <h3><b>EDUCATIONAL QUALIFICATIONS</b></h3>
        </td>
    </tr>
</table>
<table style="width: 670px;" align="center">
    <tr>
        <td><?php echo e($data->subject1); ?></td>
        <td><?php echo e($data->result1); ?></td>
    </tr>

    <tr>
        <td><?php echo e($data->subject2); ?></td>
        <td><?php echo e($data->result2); ?></td>
    </tr>

    <tr>
        <td><?php echo e($data->subject3); ?></td>
        <td><?php echo e($data->result3); ?></td>
    </tr>

    <tr>
        <td><?php echo e($data->subject4); ?></td>
        <td><?php echo e($data->result4); ?></td>
    </tr>

    <tr>
        <td><?php echo e($data->subject5); ?></td>
        <td><?php echo e($data->result5); ?></td>
    </tr>

    <tr>
        <td><?php echo e($data->subject6); ?></td>
        <td><?php echo e($data->result6); ?></td>
    </tr>

    <tr>
        <td><?php echo e($data->subject7); ?></td>
        <td><?php echo e($data->result7); ?></td>
    </tr>

    <tr>
        <td><?php echo e($data->subject8); ?></td>
        <td><?php echo e($data->result8); ?></td>
    </tr>

    <tr>
        <td><?php echo e($data->subject9); ?></td>
        <td><?php echo e($data->result9); ?></td>
    </tr>
</table>

<table style="width: 670px;" align="center">
    <tr style="margin-bottom: 20px">
        <td style="height: 50px">
            <label><b>G.C.E(A/L) Examination</b></label><br>
            
        </td>
    </tr>
</table>
<table style="width: 670px;" align="center">
    <tr>
        <td><?php echo e($data->al_subject1); ?></td>
        <td><?php echo e($data->al_result1); ?></td>
    </tr>
    <tr>
        <td><?php echo e($data->al_subject2); ?></td>
        <td><?php echo e($data->al_result2); ?></td>
    </tr>
    <tr>
        <td><?php echo e($data->al_subject3); ?></td>
        <td><?php echo e($data->al_result3); ?></td>
    </tr>
    <tr>
        <td><?php echo e($data->al_subject4); ?></td>
        <td><?php echo e($data->al_result4); ?></td>
    </tr>
    
    
    
</table>
<br><br>
<table style="width: 670px;" align="center">
    <tr>
        <td>

            <p><?php echo e($data->other_qualify); ?></p><br>
        </td>
    </tr>


















</table>
<div class="page_break" style="page-break-before: always;"></div>

<table style="width: 670px;" align="center">
    <tr style="margin-bottom: 20px">
        <td style="height: 50px">
            <label><b>ACEDEMIC QUALIFICATIONS</b></label><br>

        </td>
    </tr>
</table>
<table style="width: 670px;" align="center">
    <tr>
        <td>

            <label><?php echo e($data->a_qualify1); ?></label><br>
            <label><?php echo e($data->a_qualify2); ?></label><br>
            <label><?php echo e($data->a_qualify3); ?></label><br>
            <label><?php echo e($data->a_qualify4); ?></label><br>
        </td>
    </tr>
</table>
<table style="width: 670px;" align="center">
    <tr style="margin-bottom: 20px">
        <td style="height: 50px">
            <label><b>PROFESSIONAL QUALIFICATION</b></label><br>

        </td>
    </tr>
</table>
<table style="width: 670px;" align="center">
    <tr>
        <td>

            <label><?php echo e($data->p_qualify1); ?></label><br>
            <label><?php echo e($data->p_qualify2); ?></label><br>
            <label><?php echo e($data->p_qualify3); ?></label><br>
            <label><?php echo e($data->a_qualify4); ?></label><br>
        </td>
    </tr>
</table>
<table style="width: 670px;" align="center">
    <tr style="margin-bottom: 20px">
        <td style="height: 50px">
            <label><b>SKILLS AND COMPETENCIES</b></label><br>

        </td>
    </tr>
</table>
<table style="width: 670px;" align="center">
    <tr>
        <td>

            <label><?php echo e($data->skill1); ?></label><br>
            <label><?php echo e($data->skill2); ?></label><br>
            <label><?php echo e($data->skill3); ?></label><br>
            <label><?php echo e($data->skill4); ?></label><br>
            <label><?php echo e($data->skill5); ?></label><br>
            <label><?php echo e($data->skill6); ?></label><br>
        </td>
    </tr>
</table>
<table style="width: 670px;" align="center">
    <tr style="margin-bottom: 20px">
        <td style="height: 50px">
            <label><b>NON-RELATED REFEREES</b></label><br>

        </td>
    </tr>
</table>
<table style="width: 670px;" align="center">
    <tr>
        <td>
            <label><?php echo e($data->non_refree1_name); ?></label><br>
        </td>
    </tr>
</table>

<table style="width: 670px;" align="center">
    <tr>
        <td>
            <label><?php echo e($data->non_refree1_post); ?></label><br>
            <label><?php echo e($data->non_refree1_workplace); ?></label><br>
            <label><?php echo e($data->non_refree1_tel); ?></label><br>
        </td>
    </tr>
</table>
<br><br>
<table style="width: 670px;" align="center">
    <tr>
        <td>
            <label><?php echo e($data->non_refree2_name); ?></label><br>
        </td>
    </tr>
</table>
<table style="width: 670px;" align="center">
    <tr>
        <td>
            <label><?php echo e($data->non_refree2_post); ?></label><br>
            <label><?php echo e($data->non_refree2_workplace); ?></label><br>
            <label><?php echo e($data->non_refree2_tel); ?></label><br>
            <label>Tel: 0718660858</label><br>

        </td>
    </tr>
</table>




</body>
</html>
<?php /**PATH C:\xampp\htdocs\cvtemp\resources\views/pdf/form1_pdf.blade.php ENDPATH**/ ?>